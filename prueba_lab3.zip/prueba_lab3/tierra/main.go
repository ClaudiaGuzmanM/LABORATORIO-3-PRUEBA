package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"sync"
	"time"

	pb "github.com/EdwardFlowersGg/Lab3_INF-343/proto"
	"google.golang.org/grpc"
)

// Define la estructura del servidor que manejará las solicitudes.
// Server implementa el servidor gRPC
type server struct {
	pb.UnimplementedMunitionsServiceServer // Añade la interfaz no implementada del servicio Munitions
	AT                                     int
	MP                                     int
	mu                                     sync.Mutex
}

func (s *server) SolicitarM(ctx context.Context, req *pb.SolicitarMRequest) (*pb.SolicitarMResponse, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	// Verificar si hay suficientes municiones disponibles.
	if s.AT >= int(req.AT) && s.MP >= int(req.MP) { // Convierte req.AT y req.MP a int
		s.AT -= int(req.AT)
		s.MP -= int(req.MP)
		fmt.Printf("Recepción de solicitud desde equipo %d, %d AT y %d MP -- APROBADA -- AT EN SISTEMA: %d ; MP EN SISTEMA: %d\n", int(req.TeamID), int(req.AT), int(req.MP), s.AT, s.MP)
		return &pb.SolicitarMResponse{Aprobado: true}, nil
	}
	fmt.Printf("Recepción de solicitud desde equipo %d, %d AT y %d MP -- DENEGADA -- AT EN SISTEMA: %d ; MP EN SISTEMA: %d\n", int(req.TeamID), int(req.AT), int(req.MP), s.AT, s.MP)
	return &pb.SolicitarMResponse{Aprobado: false}, nil
}

// GenerarMunicion genera munición cada 5 segundos según las especificaciones
func (s *server) GenerarMunicion() {
	for {
		time.Sleep(5 * time.Second)
		s.mu.Lock()
		s.AT += 10
		s.MP += 5
		if s.AT > 50 {
			s.AT = 50
		}
		if s.MP > 20 {
			s.MP = 20
		}
		s.mu.Unlock()
		fmt.Print("------------------------------------------------\n")
		fmt.Printf("- (Tierra): Se Generan 10 AT y 5 MP. Inventario total: AT %d, MP %d\n", s.AT, s.MP)
		fmt.Print("------------------------------------------------\n")

	}
}

func main() {
	// Registra el servidor
	s := grpc.NewServer()
	serv := &server{AT: 0, MP: 0}
	pb.RegisterMunitionsServiceServer(s, serv) // Cambia pb.registerServer a pb.RegisterMunitionsServiceServer

	// Inicia la rutina de generación de munición
	go serv.GenerarMunicion() // Ejecuta la rutina en un goroutine
	// Escucha en el puerto 50051
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("Error al escuchar: %v", err)
	}

	// Servir
	if err := s.Serve(lis); err != nil {
		log.Fatalf("Failed to serve: %v", err)
	}
}
